Cook County property crawler
----------------------------

This crawler fetches all properties from
  http://www.cookcountyassessor.com/Property_Search/Property_Search.aspx
and stores them in an XML file and MySQL database.

Software requirements: this crawler being written using the scrapy framework,
scrapy needs to be installed for it to run. See
  http://doc.scrapy.org/en/0.14/topics/ubuntu.html
In brief, for Ubuntu Maverick, add the line
  deb http://archive.scrapy.org/ubuntu maverick main
to the file /etc/apt/sources.list and install the package
  scrapy-0.14

Before running the crawler, the MySQL connection settings have to be
edited in the file
  scrapy_test/pipelines.py
The hostname, username, password and dbname values have to be set appropriately.

To run the crawler, issue the following command on the terminal:
  python cookcounty_wrapper.py & disown

(The "&" causes it to run in the background, and the "disown" causes it to sort of 
detach from the shell, so quiting the shell may not quit this process.)

The scrapy log is generated in the file
  cookcounty_scrapy.log
and the wrapper script log is generated in the file
  cookcounty_wrapper.log

The XML output is generated in the file
  ccout.xml

Additional design details can be found in the file
  cookcounty_design.pdf

