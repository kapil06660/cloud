
import scrapy
from scrapy.spider import BaseSpider
from scrapy.item import Item, Field
from scrapy.conf import settings
from scrapy import log
import re
import urlparse

class PropertyItem(Item):
	URL = Field()
	PIN = Field()
	Township = Field()
	Neighborhood = Field()
	Class = Field()
	Description = Field()
	Type = Field()
	Use = Field()
	Apartments = Field()
	Construction = Field()
	Basement = Field()
	Attic = Field()
	CentralAir = Field()
	Fireplaces = Field()
	Garage = Field()
	Age = Field()
	Sqft = Field()
	Image = Field()
	City = Field()
	Address = Field()

class CookCountySpider(BaseSpider):
	name = "cookcounty"
	allowed_domains = ["www.cookcountyassessor.com"]
	start_urls = ["http://www.cookcountyassessor.com/Property_Search/Property_Search.aspx"]
	prev_requests = []

	def parse(self, response):
		#print "*** Got first page ***"
		#x = scrapy.selector.HtmlXPathSelector(response)
		#town_list = x.select('//select[@name="ctl00$BodyContent$town1"]/option/@value').extract()
		#requests = []
		town_to_search = settings['COOKCOUNTY_TOWN']
		#for town in [str(utown) for utown in town_list if utown == u'10']: # filter out the default value for <SELECT> option
		try:
			r = scrapy.http.FormRequest.from_response(response, formdata={"ctl00$BodyContent$town1":town_to_search},
				clickdata={"name":"ctl00$BodyContent$btn_Neighborhood"}, callback=self.search_neighbourhood)
		except:
			log.msg("ERROR GENERATING TOWN REQUEST FOR " + settings['COOKCOUNTY_TOWN'] + "." + settings['COOKCOUNTY_NEIGHBOR'] + "." + settings['COOKCOUNTY_CLASS'])
			return
		#requests.append(r)
		return r

	def search_neighbourhood(self, response):
		#print "*** Got search page ***"
		#x = scrapy.selector.HtmlXPathSelector(response)
		#neighbor_list = x.select('//select[@name="ctl00$BodyContent$cmb_Neighborhood"]/option/@value').extract()
		#requests = []
		#neighbor_list.reverse()
		neighbor_to_search = settings['COOKCOUNTY_NEIGHBOR']
		#for neighbor in [str(uneighbor) for uneighbor in neighbor_list if uneighbor == u'011']:
		try:
			r = scrapy.http.FormRequest.from_response(response, formdata={"__EVENTTARGET":"ctl00$BodyContent$cmb_Res_Class", 
				"__EVENTARGUMENT":"", "ctl00$BodyContent$cmb_Neighborhood":neighbor_to_search},
				clickdata={"name":"ctl00$BodyContent$btn_Search_Neighborhood"}, callback=self.search_neighbourhood2)
		except:
			log.msg("ERROR GENERATING NEIGHBOR REQUEST FOR " + settings['COOKCOUNTY_TOWN'] + "." + settings['COOKCOUNTY_NEIGHBOR'] + "." + settings['COOKCOUNTY_CLASS'])
			return
		#requests.append(r)
		return r

	def search_neighbourhood2(self, response):
		#print "*** Got search2 page ***"
		#x = scrapy.selector.HtmlXPathSelector(response)
		#class_list = x.select('//select[@name="ctl00$BodyContent$cmb_Res_Class"]/option/@value').extract()
		#requests = []
		#class_list.reverse()
		class_to_search = settings['COOKCOUNTY_CLASS']
		#for clas in [str(uclass) for uclass in class_list if uclass != u'0']:
		try:
			r = scrapy.http.FormRequest.from_response(response, formdata={"__EVENTTARGET":"ctl00$BodyContent$cmb_Res_Class", 
				"__EVENTARGUMENT":"", "ctl00$BodyContent$cmb_Res_Class":class_to_search},
				clickdata={"name":"ctl00$BodyContent$btn_Search_Neighborhood"}, callback=self.results_firstpage)
		except:
			log.msg("ERROR GENERATING CLASS REQUEST FOR " + settings['COOKCOUNTY_TOWN'] + "." + settings['COOKCOUNTY_NEIGHBOR'] + "." + settings['COOKCOUNTY_CLASS'])
			return
		#requests.append(r)
		return r

	def results_firstpage(self, response):
		#print "*** Got result first page ***"
		if "There are no records, Please re-select" in response.body:
			log.msg("GOT RESULT PAGE 1 FOR " + settings['COOKCOUNTY_TOWN'] + "." + settings['COOKCOUNTY_NEIGHBOR'] + "." + settings['COOKCOUNTY_CLASS'] + " PROPERTIES 0 MORE PAGE(S) 0")
			return
		if "ctl00_BodyContent_lbl_Address" in response.body:
			log.msg("GOT RESULT PAGE 1 FOR " + settings['COOKCOUNTY_TOWN'] + "." + settings['COOKCOUNTY_NEIGHBOR'] + "." + settings['COOKCOUNTY_CLASS'] + " PROPERTIES 1 MORE PAGE(S) 0")
			return scrape_property(response)
		requests = []
		x = scrapy.selector.HtmlXPathSelector(response)
		#extract links for next pages of search result
		page_links = x.select('//tr[contains(@class, "pageLinks")]/td/a')
		for page_link in page_links:
			link = page_link.select("@href").extract()[0]
			page = page_link.select("text()").extract()[0]
			match = re.match("javascript:__doPostBack\\('(.*)','(.*)'\\)", link)
			if not match:
				log.msg("Cannot follow page link:", log.INFO)
				continue
			r = scrapy.http.FormRequest.from_response(response, formdata={"__EVENTTARGET":str(match.group(1)), 
				"__EVENTARGUMENT":str(match.group(2)) }, callback=self.results_nextpage)
			r.meta['result_page'] = page
			requests.insert(0,r)
		#extract links for property by PIN
		property_links = x.select('//a[contains(@href, "property_details.aspx?pin=")]/@href').extract()
		for property_link in property_links:
			url = urlparse.urljoin(response.url, property_link)
			r = scrapy.http.Request(url, callback=self.scrape_property)
			requests.insert(0,r)
		log.msg("GOT RESULT PAGE 1 FOR " + settings['COOKCOUNTY_TOWN'] + "." + settings['COOKCOUNTY_NEIGHBOR'] + "." + settings['COOKCOUNTY_CLASS'] + " PROPERTIES " + str(len(property_links)) + " MORE PAGE(S) " + str(len(page_links)))
		return requests

	def results_nextpage(self, response):
		page = response.meta['result_page']
		#print "*** Got result page", page, "***"
		requests = []
		x = scrapy.selector.HtmlXPathSelector(response)
		property_links = x.select('//a[contains(@href, "property_details.aspx?pin=")]/@href').extract()
		for property_link in property_links:
			url = urlparse.urljoin(response.url, property_link)
			r = scrapy.http.Request(url, callback=self.scrape_property)
			requests.insert(0,r)
		log.msg("GOT RESULT PAGE " + page + " FOR " + settings['COOKCOUNTY_TOWN'] + "." + settings['COOKCOUNTY_NEIGHBOR'] + "." + settings['COOKCOUNTY_CLASS'] + " PROPERTIES " + str(len(property_links)))
		return requests

	def scrape_property(self, response):
		x = scrapy.selector.HtmlXPathSelector(response)
		item = PropertyItem()
		try:
			item['URL'] = response.url
			item['PIN'] = x.select('//span[@id="ctl00_BodyContent_lbl_pin"]/text()').extract()[0]
			item['Township'] = x.select('//span[@id="ctl00_BodyContent_lbl_town"]/text()').extract()[0].strip()
			item['Neighborhood'] = x.select('//span[@id="ctl00_BodyContent_lbl_nbhd"]/text()').extract()[0]
			item['Class'] = x.select('//span[@id="ctl00_BodyContent_lbl_class"]/text()').extract()[0]
			item['Description'] = x.select('//span[@id="ctl00_BodyContent_lbl_classdesc"]/text()').extract()[0]
			item['Type'] = x.select('//span[@id="ctl00_BodyContent_lbl_restype"]/text()').extract()[0].strip()
			item['Use'] = x.select('//span[@id="ctl00_BodyContent_lbl_puse"]/text()').extract()[0].strip()
			item['Apartments'] = x.select('//span[@id="ctl00_BodyContent_lbl_apts"]/text()').extract()[0].strip()
			item['Construction'] = x.select('//span[@id="ctl00_BodyContent_lbl_extconst"]/text()').extract()[0].strip()
			item['Basement'] = x.select('//span[@id="ctl00_BodyContent_lbl_Basement"]/text()').extract()[0].strip()
			item['Attic'] = x.select('//span[@id="ctl00_BodyContent_lbl_attic"]/text()').extract()[0].strip()
			item['CentralAir'] = x.select('//span[@id="ctl00_BodyContent_lbl_CentralAir"]/text()').extract()[0]
			item['Fireplaces'] = x.select('//span[@id="ctl00_BodyContent_lbl_fireplace"]/text()').extract()[0]
			item['Garage'] = x.select('//span[@id="ctl00_BodyContent_lbl_garage"]/text()').extract()[0].strip()
			item['Age'] = x.select('//span[@id="ctl00_BodyContent_lbl_age"]/text()').extract()[0]
			sqft = x.select('//span[@id="ctl00_BodyContent_lbl_bsf1"]/text()').extract()[0]
			item['Sqft'] = filter(lambda ch: ch.isdigit(), sqft)
			pin = filter(lambda ch: ch.isdigit(), item['PIN'])
			item['Image'] = "http://www.cookcountyassessor.com/Property_Search/Property_Large_images_Output/" + pin + "_AA.JPG"
			item['City'] = x.select('//span[@id="ctl00_BodyContent_lbl_City"]/text()').extract()[0]
			item['Address'] = x.select('//span[@id="ctl00_BodyContent_lbl_Address"]/text()').extract()[0] + " , " + item['City']
		except IndexError:
			# some field was not found
			log.msg("Could not extract property item from url: " + response.url, log.INFO)
			return
		return item

