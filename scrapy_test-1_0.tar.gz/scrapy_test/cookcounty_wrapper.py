
from town_neighbor import town_neighbor_dict
class_list = ['202', '203', '204', '205', '206', '207', '208', '209', '210', '211', '212', '234', '278', '295', '299']

import sys
import os
from datetime import datetime

log_file = open("cookcounty_wrapper.log", "a+")
for town,neighbor_list in town_neighbor_dict.items():
	for neighbor in neighbor_list:
		for clas in class_list:
			cmd = "scrapy crawl cookcounty -s COOKCOUNTY_TOWN=" + town + " -s COOKCOUNTY_NEIGHBOR=" + neighbor \
					+ " -s COOKCOUNTY_CLASS=" + clas
			log_file.write(str(datetime.now()) + " [cookcounty_wrapper] INFO: Executing: " + cmd + "\n")
			log_file.flush()
			ret = os.system(cmd)
			if ret != 0:
				log_file.write(str(datetime.now()) + " [cookcounty_wrapper] ERROR: Exiting on scrapy error code: " + str(ret) + "\n")
				log_file.flush()
				sys.exit(ret)

print "Finised running cookcounty_wrapper.py."
