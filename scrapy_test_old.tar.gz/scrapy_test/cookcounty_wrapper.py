
from town_neighbor import town_neighbor_dict
class_list = ['202', '203', '204', '205', '206', '207', '208', '209', '210', '211', '212', '234', '278', '295', '299']

import sys
import os

for town,neighbor_list in town_neighbor_dict.items():
	for neighbor in neighbor_list:
		for clas in class_list:
			cmd = "scrapy crawl cookcounty -s COOKCOUNTY_TOWN=" + town + " -s COOKCOUNTY_NEIGHBOR=" + neighbor \
					+ " -s COOKCOUNTY_CLASS=" + clas
			print "*** Executing:", cmd
			ret = os.system(cmd)
			if ret != 0:
				print "*** Exiting on scrapy error code:", ret
				print "*** Last command ran:", cmd
				sys.exit(ret)


