
import scrapy
from scrapy.spider import BaseSpider
from scrapy.item import Item, Field
from scrapy.conf import settings
import traceback

class MyItem(Item):
	url = Field()
	title = Field()

class CookCountySpider(BaseSpider):
	name = "vaibhavk"
	#allowed_domains = ["www.cse.iitb.ac.in"]
	start_urls = ["http://www.cse.iitb.ac.in/alumni/~vaibhavk09/"]

	def parse(self, response):
		traceback.print_stack()
		print "DEPTH_PRIORITY=" + str(settings['DEPTH_PRIORITY'])
		print "SCHEDULER_DISK_QUEUE=" + settings['SCHEDULER_DISK_QUEUE']
		print "SCHEDULER_MEMORY_QUEUE=" + settings['SCHEDULER_MEMORY_QUEUE']
		req1 = scrapy.http.Request("http://www.google.co.in", callback=self.parse2) #, priority=5)
		req2 = scrapy.http.Request("http://dataone.in", callback=self.parse2) #, priority=100)
		#return [req1,req2]
		yield req1
		yield req2

	def parse2(self, response):
		print "*** Got 2nd page ***"
		print "URL:", response.url
		req1 = scrapy.http.Request("http://slashdot.org", callback=self.parse3) #, priority=15)
		req2 = scrapy.http.Request("http://www.phoronix.com/scan.php?page=home", callback=self.parse3) #, priority=20)
		#return [req1,req2]
		yield req1
		yield req2

	def parse3(self, response):
		print "*** Got 3rd page ***"
		print "URL:", response.url
