from scrapy.xlib.pydispatch import dispatcher
from scrapy import signals

class SpiderOpenCloseLogging(object):

    def __init__(self):
        dispatcher.connect(self.spider_idle, signal=signals.spider_idle)

    def spider_idle(self, spider):
        log.msg("closed spider %s" % spider.name)
