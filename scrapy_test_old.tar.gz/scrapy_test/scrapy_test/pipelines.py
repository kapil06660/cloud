
from xml.dom.minidom import Text
import MySQLdb

def escape_quotes(text):
	escaped_text = ""
	for ch in text:
		if ch == "'": escaped_text += "\\"
		escaped_text += ch
	return escaped_text

class ItemSaver(object):

	def __init__(self):
		print "*** Initializing ItemSaver ***"
		try:
			self.xml_file = open("ccout.xml", "r+")
			self.xml_file.seek(0, 2) # seek to end
			if self.xml_file.tell() >= 11:
				self.xml_file.seek(-11, 1)
				if self.xml_file.read() == "</Results>\n":
					self.xml_file.seek(-11, 1)  # erase the last </Results> end tag
					self.xml_file.truncate()
		except IOError as e:
			self.xml_file = open("ccout.xml", "w+")
			self.xml_file.write("<Results>\n")

		hostname = "localhost"
		username = "root"
		password = "abc123"
		dbname   = "testdb"

		self.connection = MySQLdb.connect(hostname, username, password, dbname)
		self.cursor = self.connection.cursor()
		self.cursor.execute('CREATE TABLE IF NOT EXISTS CookCountyProperty ( \
				URL VARCHAR(200), \
				PIN VARCHAR(50) PRIMARY KEY, \
				Township VARCHAR(50), \
				Neighborhood VARCHAR(50), \
				Class VARCHAR(50), \
				Description VARCHAR(200), \
				Type VARCHAR(50), \
				PropUse VARCHAR(50), \
				Apartments VARCHAR(50), \
				Construction VARCHAR(50), \
				Basement VARCHAR(50), \
				Attic VARCHAR(50), \
				CentralAir VARCHAR(50), \
				Fireplaces VARCHAR(50), \
				Garage VARCHAR(50), \
				Age VARCHAR(50), \
				Sqft VARCHAR(50), \
				Image VARCHAR(200), \
				City VARCHAR(50), \
				Address VARCHAR(200) )' )


	def process_item(self, item, spider):
		self.xml_file.write("  <record>\n")
		for name,value in item.items():
			text = Text()
			text.data = value
			self.xml_file.write("    <" + name + ">" + text.toxml() + "</" + name + ">\n")
		self.xml_file.write("  </record>\n")
		self.cursor.execute("INSERT IGNORE INTO CookCountyProperty VALUES ( " +\
				"'" + item['URL'] + "' , " +\
				"'" + item['PIN'] + "' , " +\
				"'" + item['Township'] + "' , " +\
				"'" + item['Neighborhood'] + "' , " +\
				"'" + item['Class'] + "' , " +\
				"'" + escape_quotes(item['Description']) + "' , " +\
				"'" + item['Type'] + "' , " +\
				"'" + item['Use'] + "' , " +\
				"'" + item['Apartments'] + "' , " +\
				"'" + item['Construction'] + "' , " +\
				"'" + item['Basement'] + "' , " +\
				"'" + item['Attic'] + "' , " +\
				"'" + item['CentralAir'] + "' , " +\
				"'" + item['Fireplaces'] + "' , " +\
				"'" + item['Garage'] + "' , " +\
				"'" + item['Age'] + "' , " +\
				"'" + item['Sqft'] + "' , " +\
				"'" + item['Image'] + "' , " +\
				"'" + escape_quotes(item['City']) + "' , " +\
				"'" + escape_quotes(item['Address']) + "' )" )
		# Note: use REPLACE in place of INSERT IGNORE if you want to save new value instead of keeping old value
		return item

	def open_spider(self, spider):
		pass

	def close_spider(self, spider):
		self.xml_file.write("</Results>\n")
